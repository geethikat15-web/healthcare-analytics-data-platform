-- Reconciliation: RAW vs staging vs mart row counts and amount totals.
-- Any row with status = 'MISMATCH' should trigger an alert.
-- (Adjust ANALYTICS_* schema names if your dbt target schema differs.)

with counts as (
    select 'admissions' as entity,
           (select count(*) from HEALTHCARE_DB.RAW.ADMISSIONS)                 as raw_rows,
           (select count(*) from HEALTHCARE_DB.ANALYTICS_STAGING.STG_ADMISSIONS) as staging_rows,
           (select count(*) from HEALTHCARE_DB.ANALYTICS_MARTS.FCT_ADMISSIONS)   as mart_rows
    union all
    select 'patients',
           (select count(*) from HEALTHCARE_DB.RAW.PATIENTS),
           (select count(*) from HEALTHCARE_DB.ANALYTICS_STAGING.STG_PATIENTS),
           (select count(*) from HEALTHCARE_DB.ANALYTICS_MARTS.DIM_PATIENTS)
)
select entity, raw_rows, staging_rows, mart_rows,
       iff(raw_rows = staging_rows and staging_rows = mart_rows, 'OK', 'MISMATCH') as status
from counts;

-- Billing totals must match between RAW and the fact table
with totals as (
    select
        (select sum(billed_amount) from HEALTHCARE_DB.RAW.BILLING)                       as raw_billed,
        (select sum(billed_amount) from HEALTHCARE_DB.ANALYTICS_MARTS.FCT_ADMISSIONS)    as mart_billed
)
select raw_billed, mart_billed,
       iff(raw_billed = mart_billed, 'OK', 'MISMATCH') as status
from totals;
