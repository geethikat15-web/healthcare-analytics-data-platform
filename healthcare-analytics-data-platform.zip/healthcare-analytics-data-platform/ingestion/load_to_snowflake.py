"""Validate source files and load them into Snowflake RAW tables.

Usage:
    python ingestion/load_to_snowflake.py --source data/sample
"""
import argparse
import logging
import os
import sys
import time
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("ingestion")

# Expected schema per source file: table name -> required columns
EXPECTED_SCHEMAS = {
    "patients": ["patient_id", "first_name", "last_name", "date_of_birth", "gender", "state", "updated_at"],
    "admissions": ["admission_id", "patient_id", "admit_date", "discharge_date", "department", "diagnosis_code", "updated_at"],
    "billing": ["bill_id", "admission_id", "billed_amount", "insurance_paid", "patient_paid", "billing_date", "updated_at"],
}
PRIMARY_KEYS = {"patients": "patient_id", "admissions": "admission_id", "billing": "bill_id"}


def validate(df: pd.DataFrame, table: str) -> None:
    """Schema, empty-file, null-key and duplicate-key checks. Raises ValueError on failure."""
    missing = set(EXPECTED_SCHEMAS[table]) - set(df.columns)
    if missing:
        raise ValueError(f"{table}: missing columns {sorted(missing)}")
    if df.empty:
        raise ValueError(f"{table}: file has no rows")
    pk = PRIMARY_KEYS[table]
    if df[pk].isnull().any():
        raise ValueError(f"{table}: null values in primary key {pk}")
    if df[pk].duplicated().any():
        raise ValueError(f"{table}: duplicate values in primary key {pk}")
    log.info("%s: validation passed (%d rows)", table, len(df))


def connect():
    import snowflake.connector

    return snowflake.connector.connect(
        account=os.environ["SNOWFLAKE_ACCOUNT"],
        user=os.environ["SNOWFLAKE_USER"],
        password=os.environ["SNOWFLAKE_PASSWORD"],
        role=os.environ.get("SNOWFLAKE_ROLE", "LOADER_ROLE"),
        warehouse=os.environ.get("SNOWFLAKE_WAREHOUSE", "LOAD_WH"),
        database=os.environ.get("SNOWFLAKE_DATABASE", "HEALTHCARE_DB"),
        schema=os.environ.get("SNOWFLAKE_SCHEMA", "RAW"),
    )


def load_with_retry(conn, df: pd.DataFrame, table: str, retries: int = 3) -> int:
    """Load a DataFrame into RAW.<TABLE> with retries and exponential backoff."""
    from snowflake.connector.pandas_tools import write_pandas

    df = df.copy()
    df.columns = [c.upper() for c in df.columns]
    df["LOADED_AT"] = pd.Timestamp.now("UTC").tz_localize(None)
    for attempt in range(1, retries + 1):
        try:
            _, _, nrows, _ = write_pandas(
                conn, df, table.upper(), auto_create_table=True, overwrite=True
            )
            log.info("%s: loaded %d rows", table, nrows)
            return nrows
        except Exception as exc:  # noqa: BLE001
            log.warning("%s: load attempt %d/%d failed: %s", table, attempt, retries, exc)
            if attempt == retries:
                raise
            time.sleep(2 ** attempt)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="data/sample", help="folder containing the CSV files")
    parser.add_argument("--validate-only", action="store_true", help="check files without loading")
    args = parser.parse_args()

    load_dotenv()
    frames = {}
    for table in EXPECTED_SCHEMAS:
        path = Path(args.source) / f"{table}.csv"
        if not path.exists():
            log.error("Missing source file: %s", path)
            return 1
        df = pd.read_csv(path)
        validate(df, table)
        frames[table] = df

    if args.validate_only:
        log.info("Validation only: nothing loaded.")
        return 0

    conn = connect()
    try:
        for table, df in frames.items():
            load_with_retry(conn, df, table)
    finally:
        conn.close()
    log.info("All tables loaded successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
