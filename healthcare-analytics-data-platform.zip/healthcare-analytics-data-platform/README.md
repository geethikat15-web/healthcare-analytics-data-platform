# Healthcare Analytics Data Platform

An end-to-end ELT project that loads patient, admissions, and billing data into **Snowflake** using **Python**, then models it into analytics-ready tables with **dbt**.

**Stack:** Snowflake · dbt · Python · Git / GitHub Actions (CI) · Tableau (reporting)

## Architecture

```
CSV / JSON / API sources
        |
        v
Python ingestion (validate schema, keys, duplicates; retries + logging)
        |
        v
Snowflake RAW (patients, admissions, billing)
        |
        v
dbt staging -> dbt intermediate -> dbt marts (dim_patients, fct_admissions)
        |
        v
Reconciliation checks + Tableau dashboards
```

## Project structure

| Path | Purpose |
|---|---|
| `data/sample/` | Small synthetic sample files (no real patient data) |
| `ingestion/load_to_snowflake.py` | Validation + load into Snowflake RAW tables |
| `snowflake/setup.sql` | Warehouses, schemas, and role-based access control |
| `dbt_project/` | dbt models (staging, intermediate, marts), tests, macros, source freshness |
| `reconciliation/` | SQL checks comparing row counts and totals across layers |
| `.github/workflows/ci.yml` | CI: data validation and dbt parse on every pull request |

## Data modeling

- **Staging:** one view per source table; type casting, cleaning, standardizing names.
- **Intermediate:** joins admissions with aggregated billing; derives length of stay.
- **Marts:** `dim_patients` (age bands via a reusable macro) and `fct_admissions` (**incremental** model, unique key `admission_id`).

## Data quality

- Python checks: required columns, empty files, null primary keys, duplicate keys.
- dbt tests: `unique`, `not_null`, `relationships`, plus a singular test for negative length of stay.
- Source freshness: warn after 24h, error after 48h.
- Reconciliation SQL compares RAW vs staging vs mart counts and billing totals.

## How to run

```bash
# 1. Install
pip install -r requirements.txt

# 2. Configure credentials
cp .env.example .env          # then edit .env

# 3. One-time Snowflake setup: run snowflake/setup.sql in a Snowflake worksheet

# 4. Validate and load the sample data
python ingestion/load_to_snowflake.py --source data/sample --validate-only
python ingestion/load_to_snowflake.py --source data/sample

# 5. Build and test the dbt models
cp dbt_project/profiles.yml.example ~/.dbt/profiles.yml
cd dbt_project
dbt source freshness
dbt build

# 6. Run reconciliation checks
# Execute reconciliation/reconcile_row_counts.sql in Snowflake
```

## Notes

All data in this repository is synthetic and for demonstration only. Credentials are never committed; `.env` is git-ignored.
