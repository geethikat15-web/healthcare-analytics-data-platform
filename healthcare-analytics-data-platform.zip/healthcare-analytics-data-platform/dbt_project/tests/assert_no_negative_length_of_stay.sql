-- Singular test: fails if any admission has a discharge before its admit date
select admission_id
from {{ ref('fct_admissions') }}
where length_of_stay_days < 0
