{% macro age_band(age_column) %}
    case
        when {{ age_column }} < 18 then '0-17'
        when {{ age_column }} < 35 then '18-34'
        when {{ age_column }} < 50 then '35-49'
        when {{ age_column }} < 65 then '50-64'
        else '65+'
    end
{% endmacro %}
