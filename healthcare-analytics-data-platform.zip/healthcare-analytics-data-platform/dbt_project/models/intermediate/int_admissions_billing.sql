-- One row per admission, enriched with billing totals and length of stay
with admissions as (
    select * from {{ ref('stg_admissions') }}
),
billing as (
    select
        admission_id,
        sum(billed_amount)  as billed_amount,
        sum(insurance_paid) as insurance_paid,
        sum(patient_paid)   as patient_paid
    from {{ ref('stg_billing') }}
    group by admission_id
)
select
    a.admission_id,
    a.patient_id,
    a.admit_date,
    a.discharge_date,
    datediff('day', a.admit_date, a.discharge_date) as length_of_stay_days,
    a.department,
    a.diagnosis_code,
    coalesce(b.billed_amount, 0)  as billed_amount,
    coalesce(b.insurance_paid, 0) as insurance_paid,
    coalesce(b.patient_paid, 0)   as patient_paid,
    a.updated_at,
    a.loaded_at
from admissions a
left join billing b on a.admission_id = b.admission_id
