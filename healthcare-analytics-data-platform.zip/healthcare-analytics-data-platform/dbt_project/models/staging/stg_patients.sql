select
    patient_id,
    initcap(first_name)      as first_name,
    initcap(last_name)       as last_name,
    to_date(date_of_birth)   as date_of_birth,
    upper(gender)            as gender,
    upper(state)             as state,
    to_timestamp(updated_at) as updated_at,
    loaded_at
from {{ source('raw', 'patients') }}
