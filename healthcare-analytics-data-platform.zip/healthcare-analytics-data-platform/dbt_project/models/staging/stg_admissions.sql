select
    admission_id,
    patient_id,
    to_date(admit_date)      as admit_date,
    to_date(discharge_date)  as discharge_date,
    department,
    upper(diagnosis_code)    as diagnosis_code,
    to_timestamp(updated_at) as updated_at,
    loaded_at
from {{ source('raw', 'admissions') }}
