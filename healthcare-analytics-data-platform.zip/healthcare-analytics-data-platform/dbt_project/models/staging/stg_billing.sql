select
    bill_id,
    admission_id,
    billed_amount::number(12,2)  as billed_amount,
    insurance_paid::number(12,2) as insurance_paid,
    patient_paid::number(12,2)   as patient_paid,
    to_date(billing_date)        as billing_date,
    to_timestamp(updated_at)     as updated_at,
    loaded_at
from {{ source('raw', 'billing') }}
