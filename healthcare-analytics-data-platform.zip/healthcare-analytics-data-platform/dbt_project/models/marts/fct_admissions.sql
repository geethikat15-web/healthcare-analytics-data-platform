{{ config(
    materialized='incremental',
    unique_key='admission_id',
    on_schema_change='append_new_columns'
) }}

select
    admission_id,
    patient_id,
    admit_date,
    discharge_date,
    length_of_stay_days,
    department,
    diagnosis_code,
    billed_amount,
    insurance_paid,
    patient_paid,
    billed_amount - insurance_paid - patient_paid as outstanding_balance,
    updated_at,
    loaded_at
from {{ ref('int_admissions_billing') }}

{% if is_incremental() %}
where updated_at > (select max(updated_at) from {{ this }})
{% endif %}
