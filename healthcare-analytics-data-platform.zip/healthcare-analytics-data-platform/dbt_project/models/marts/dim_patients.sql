select
    patient_id,
    first_name,
    last_name,
    date_of_birth,
    datediff('year', date_of_birth, current_date)                   as age,
    {{ age_band("datediff('year', date_of_birth, current_date)") }} as age_band,
    gender,
    state
from {{ ref('stg_patients') }}
